import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-searches',
  templateUrl: './searches.page.html',
  styleUrls: ['./searches.page.scss'],
})
export class SearchesPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
